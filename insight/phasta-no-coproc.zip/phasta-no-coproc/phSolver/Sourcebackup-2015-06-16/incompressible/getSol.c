#include "usr.h"
void getSol ( UsrHd usrHd,
              double* Dy  )
{

     Dy = usrHd->solinc;

}
