extern int phasta ( int ,  char* argv[] );

int 
main( int argc,   
      char* argv[] ) {

  phasta ( argc, argv);  
  
  return 0;
}
