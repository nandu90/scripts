      PARAMETER (maxtask = 100)

      integer INEWCOMM
      integer sevsegtype(maxtask,17)

      common /newcom/ INEWCOMM
      common /newtyp/ sevsegtype
