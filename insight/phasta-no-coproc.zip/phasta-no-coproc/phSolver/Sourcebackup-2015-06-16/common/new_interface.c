/* This file provides interface functions for 'partial ' random 
   access into the PHASTA input files 

   Anil Karanam March 2001 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "mpi.h"
#include "phastaIO.h"
#include "common_c.h"

#include <sys/types.h>
#include <time.h>

#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>

#include <FCMangle.h>
#include "new_interface.h"


#ifdef intel
#include <winsock2.h>
#else
#include <unistd.h>
#include <strings.h>
#endif


//MR CHANGE

void igetMinMaxAvg(int *ivalue, double *stats, int *statRanks) {
  int isThisRank;

  double *value = (double*)malloc(sizeof(double));
  *value = 1.0*(*ivalue);

  rgetMinMaxAvg(value,stats,statRanks);

  /* MPI_Allreduce(value,&stats[0],1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  isThisRank=workfc.numpe+1;
  if(*value==stats[0])
    isThisRank=workfc.myrank; 
  MPI_Allreduce(&isThisRank,&statRanks[0],1,MPI_INT,MPI_MIN,MPI_COMM_WORLD);

  MPI_Allreduce(value,&stats[1],1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  isThisRank=workfc.numpe+1;
  if(*value==stats[1])
    isThisRank=workfc.myrank; 
  MPI_Allreduce(&isThisRank,&statRanks[1],1,MPI_INT,MPI_MIN,MPI_COMM_WORLD);

  MPI_Allreduce(value,&stats[2],1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
  stats[2] /= workfc.numpe; */

  free(value);
}

void rgetMinMaxAvg(double *value, double *stats, int *statRanks) {
  int isThisRank;

  MPI_Allreduce(value,&stats[0],1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  isThisRank=workfc.numpe+1;
  if(*value==stats[0])
    isThisRank=workfc.myrank; 
  MPI_Allreduce(&isThisRank,&statRanks[0],1,MPI_INT,MPI_MIN,MPI_COMM_WORLD);

  MPI_Allreduce(value,&stats[1],1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  isThisRank=workfc.numpe+1;
  if(*value==stats[1])
    isThisRank=workfc.myrank; 
  MPI_Allreduce(&isThisRank,&statRanks[1],1,MPI_INT,MPI_MIN,MPI_COMM_WORLD);

  MPI_Allreduce(value,&stats[2],1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
  stats[2] /= workfc.numpe;

  double sqValue = (*value)*(*value), sqValueAvg = 0.;
  MPI_Allreduce(&sqValue,&sqValueAvg,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
  sqValueAvg /= workfc.numpe;
  // stats[3] = sqValueAvg;

  stats[3] = sqrt(sqValueAvg-stats[2]*stats[2]);
}

void print_mesh_stats(void) {
  int statRanks[2];
  double iStats[4], rStats[4];

  igetMinMaxAvg(&conpar.nshg,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("nshg    : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);
  igetMinMaxAvg(&conpar.numel,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("numel   : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);
  igetMinMaxAvg(&conpar.numelb,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("numelb  : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);
  igetMinMaxAvg(&conpar.nnz_tot,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("nnz_tot : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);
}

void print_mpi_stats(void) {
  int statRanks[2];
  double iStats[4], rStats[4];

  igetMinMaxAvg(&mpistats.iISend,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("iISend : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);
  igetMinMaxAvg(&mpistats.iIRecv,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("iIRecv : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);
  igetMinMaxAvg(&mpistats.iWaitAll,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("iWtAll : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);
  igetMinMaxAvg(&mpistats.iAllR,iStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("iAllR  : min [%d,%d], max[%d,%d] and avg[.,%d] (rms=%d)\n",statRanks[0],(int)iStats[0],statRanks[1],(int)iStats[1],(int)iStats[2],(int)iStats[3]);

  rgetMinMaxAvg(&mpistats.rISend,rStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("rISend : min [%d,%2.5f], max[%d,%2.5f] and avg[.,%2.5f] (rms=%2.5f)\n",statRanks[0],rStats[0],statRanks[1],rStats[1],rStats[2],rStats[3]);
  rgetMinMaxAvg(&mpistats.rIRecv,rStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("rIRecv : min [%d,%2.5f], max[%d,%2.5f] and avg[.,%2.5f] (rms=%2.5f)\n",statRanks[0],rStats[0],statRanks[1],rStats[1],rStats[2],rStats[3]);
  rgetMinMaxAvg(&mpistats.rWaitAll,rStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("rWtAll : min [%d,%2.5f], max[%d,%2.5f] and avg[.,%2.5f] (rms=%2.5f)\n",statRanks[0],rStats[0],statRanks[1],rStats[1],rStats[2],rStats[3]);
  rgetMinMaxAvg(&mpistats.rCommu,rStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("rCommu : min [%d,%2.5f], max[%d,%2.5f] and avg[.,%2.5f] (rms=%2.5f)\n",statRanks[0],rStats[0],statRanks[1],rStats[1],rStats[2],rStats[3]);
  rgetMinMaxAvg(&mpistats.rAllR,rStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("rAllR  : min [%d,%2.5f], max[%d,%2.5f] and avg[.,%2.5f] (rms=%2.5f)\n",statRanks[0],rStats[0],statRanks[1],rStats[1],rStats[2],rStats[3]);
}

//void print_system_stats(double tcorecp[2]) {
void print_system_stats(double *tcorecp) {
  int statRanks[2];
  double iStats[4], rStats[4];
  
  double syst_assembly, syst_solve;

  syst_assembly = tcorecp[0];
  syst_solve = tcorecp[1];

  rgetMinMaxAvg(&syst_assembly,rStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("Elm. form. : min [%d,%2.5f], max[%d,%2.5f] and avg[.,%2.5f] (rms=%2.5f)\n",statRanks[0],rStats[0],statRanks[1],rStats[1],rStats[2],rStats[3]);

  rgetMinMaxAvg(&syst_solve,rStats,statRanks);
  if(workfc.myrank==workfc.master)
    printf("Lin. alg. sol : min [%d,%2.5f], max[%d,%2.5f] and avg[.,%2.5f] (rms=%2.5f)\n",statRanks[0],rStats[0],statRanks[1],rStats[1],rStats[2],rStats[3]);

  //printf("rank %d - syst_assembly %f - syst_solve %f\n",workfc.myrank,syst_assembly,syst_solve);
}
//MR CHANGE END


void 
Write_Restart(  int* pid, 
                int* stepno, 
                int* nshg, 
                int* numVars,
		double* soltime,
                double* array1, 
                double* array2 ) {

    char fname[255];
    char rfile[60];
    char existingfile[30], linkfile[30];
    int irstou;
    int magic_number = 362436;
    int* mptr = &magic_number;
    time_t timenow = time ( &timenow);
    double version=0.0;
    int isize, nitems;
    int iarray[10];

    if (workfc.numpe > fronts.idirtrigger) {
	if(outpar.iMeshingTool == 1) {
        sprintf(rfile,"%d/restart.%d.%d",((int)((*pid)/fronts.idirstep)),*stepno,*pid+1);  //For Chef runs
	}
	else if(outpar.iMeshingTool == 0) {
        sprintf(rfile,"%d-set/restart.%d.%d",((int)((*pid)/fronts.idirstep))*fronts.idirstep,*stepno,*pid+1);   // Igor, August 2012
	}

        }
     else
    sprintf(rfile,"restart.%d.%d",*stepno,*pid+1);
    openfile(rfile,"write", &irstou);

    /* writing the top ascii header for the restart file */

    writestring( &irstou,"# PHASTA Input File Version 2.0\n");
    writestring( &irstou,
                  "# format \"keyphrase : sizeofnextblock usual headers\"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# Output generated by phasta version (NOT YET CURRENT): %lf \n", version);
    writestring( &irstou, fname );

    bzero( (void*)fname, 255 );
    gethostname(fname,255);
    writestring( &irstou,"# This result was produced on: ");
    writestring( &irstou, fname );
    writestring( &irstou,"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# %s\n", ctime( &timenow ));
    writestring( &irstou, fname );

    bzero( (void*)fname, 255 );
    isize = 1;
    nitems = 1;
    iarray[ 0 ] = 1;
    writeheader( &irstou, "TimeStamp ", 
                  (void*)iarray, &nitems, &isize, "double", phasta_iotype );
    writedatablock( &irstou, "TimeStamp ",
                     (void*)soltime, &nitems, "double", phasta_iotype );

    isize = 1;
    nitems = 1;
    iarray[ 0 ] = 1;
    writeheader( &irstou, "byteorder magic number ", 
                  (void*)iarray, &nitems, &isize, "integer", phasta_iotype );
    
    nitems = 1;
    writedatablock( &irstou, "byteorder magic number ",
                     (void*)mptr, &nitems, "integer", phasta_iotype );
    
    
    bzero( (void*)fname, 255 );
    sprintf(fname,"number of modes : < 0 > %d\n", *nshg);
    writestring( &irstou, fname );
    
    bzero( (void*)fname, 255 );
    sprintf(fname,"number of variables : < 0 > %d\n", *numVars);
    writestring( &irstou, fname );
        
    
    isize = (*nshg)*(*numVars);
    nitems = 3;
    iarray[ 0 ] = (*nshg);
    iarray[ 1 ] = (*numVars);
    iarray[ 2 ] = (*stepno);
    writeheader( &irstou, "solution ", 
                  (void*)iarray, &nitems, &isize, "double", phasta_iotype );
    
        
    nitems = (*nshg)*(*numVars);
    writedatablock( &irstou, "solution ",
                     (void*)(array1), &nitems, "double", phasta_iotype );
        
   

    nitems = 3;
    writeheader( &irstou, "time derivative of solution ", 
                  (void*)iarray, &nitems, &isize, "double", phasta_iotype );
    
    
    nitems = (*nshg)*(*numVars);
    writedatablock( &irstou, "time derivative of solution ",
                     (void*)(array2), &nitems, "double", phasta_iotype );

        
    closefile( &irstou, "write" );
      
    MPI_Barrier(MPI_COMM_WORLD);

    /* create a soft link of the restart we just wrote to restart.latest
     this is the file the next run will always try to start from */
// Igor, 11/18/2009
/*    sprintf( linkfile, "restart.latest.%d", *pid+1 );
    unlink( linkfile );
    sprintf( existingfile, "restart.%d.%d", *stepno, *pid+1 );
    link( existingfile, linkfile );
*/
}


void
Write_Error(  int* pid,
              int* stepno,
              int* nshg,
              int* numVars,
              double* array1 ) {


    char fname[255];
    char rfile[60];
    int irstou;
    int magic_number = 362436;
    int* mptr = &magic_number;
    time_t timenow = time ( &timenow);
    double version=0.0;
    int isize, nitems;
    int iarray[10];


    if (workfc.numpe > fronts.idirtrigger) {
        if(outpar.iMeshingTool == 1) {
        sprintf(rfile,"%d/restart.%d.%d",((int)((*pid)/fronts.idirstep)),*stepno,*pid+1);  //For Chef runs
        }
        else if(outpar.iMeshingTool == 0) {
        sprintf(rfile,"%d-set/restart.%d.%d",((int)((*pid)/fronts.idirstep))*fronts.idirstep,*stepno,*pid+1);   // Igor, August 2012
        }

        }
     else
    sprintf(rfile,"restart.%d.%d",*stepno,*pid+1);
    openfile(rfile,"append", &irstou);

    isize = (*nshg)*(*numVars);
    nitems = 3;
    iarray[ 0 ] = (*nshg);
    iarray[ 1 ] = (*numVars);
    iarray[ 2 ] = (*stepno);
    writeheader( &irstou, "errors", (void*)iarray, &nitems, &isize, "double", phasta_iotype );


    nitems = (*nshg)*(*numVars);
    writedatablock( &irstou, "errors ", (void*)(array1), &nitems, "double", phasta_iotype );

    closefile( &irstou, "append" );

}

/*
void 
Write_Error(  int* pid, 
              int* stepno, 
              int* nshg, 
              int* numVars,
              double* array1 ) { 


    char fname[255];
    char rfile[60];
    int irstou;
    int magic_number = 362436;
    int* mptr = &magic_number;
    time_t timenow = time ( &timenow);
    double version=0.0;
    int isize, nitems;
    int iarray[10];

    sprintf(rfile,"error.%d.%d",*stepno,*pid+1);
    openfile_(rfile,"write", &irstou);

    writestring_( &irstou,"# PHASTA Error File Version 2.0\n");
    writestring_( &irstou,
                  "# format \"keyphrase : sizeofnextblock usual headers\"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# Output generated by phasta version (NOT YET CURRENT): %lf \n", version);
    writestring_( &irstou, fname );

    bzero( (void*)fname, 255 );
    gethostname(fname,255);
    writestring_( &irstou,"# This result was produced on: ");
    writestring_( &irstou, fname );
    writestring_( &irstou,"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# %s\n", ctime( &timenow ));
    writestring_( &irstou, fname );
        
    isize = 1;
    nitems = 1;
    iarray[ 0 ] = 1;
    writeheader_( &irstou, "byteorder magic number ", 
                  (void*)iarray, &nitems, &isize, "integer", phasta_iotype );
    
    nitems = 1;
    writedatablock_( &irstou, "byteorder magic number ",
                     (void*)mptr, &nitems, "integer", phasta_iotype );
    
    
    bzero( (void*)fname, 255 );
    sprintf(fname,"number of modes : < 0 > %d\n", *nshg);
    writestring_( &irstou, fname );
    
    bzero( (void*)fname, 255 );
    sprintf(fname,"number of variables : < 0 > %d\n", *numVars);
    writestring_( &irstou, fname );
    
    isize = (*nshg)*(*numVars);
    nitems = 3;
    iarray[ 0 ] = (*nshg);
    iarray[ 1 ] = (*numVars);
    iarray[ 2 ] = (*stepno);
    writeheader_( &irstou, "errors", (void*)iarray, &nitems, &isize, "double", phasta_iotype );
    
        
    nitems = (*nshg)*(*numVars);
    writedatablock_( &irstou, "errors ", (void*)(array1), &nitems, "double", phasta_iotype );

    closefile_( &irstou, "write" );
    
}

*/

void 
Write_Displ(  int* pid, 
              int* stepno, 
              int* nshg, 
              int* numVars,
              double* array1 ) { 


    char fname[255];
    char rfile[60];
    int irstou;
    int magic_number = 362436;
    int* mptr = &magic_number;
    time_t timenow = time ( &timenow);
    double version=0.0;
    int isize, nitems;
    int iarray[10];

    if (workfc.numpe > fronts.idirtrigger) {
        if(outpar.iMeshingTool == 1) {
        sprintf(rfile,"%d/restart.%d.%d",((int)((*pid)/fronts.idirstep)),*stepno,*pid+1);  //For Chef runs
        }
        else if(outpar.iMeshingTool == 0) {
        sprintf(rfile,"%d-set/restart.%d.%d",((int)((*pid)/fronts.idirstep))*fronts.idirstep,*stepno,*pid+1);   // Igor, August 2012
        }

        }
     else
    sprintf(rfile,"restart.%d.%d",*stepno,*pid+1);
    openfile(rfile,"append", &irstou);

    isize = (*nshg)*(*numVars);
    nitems = 3;
    iarray[ 0 ] = (*nshg);
    iarray[ 1 ] = (*numVars);
    iarray[ 2 ] = (*stepno);
    writeheader( &irstou, "displacement", (void*)iarray, &nitems, &isize, "double", phasta_iotype );
    
        
    nitems = (*nshg)*(*numVars);
    writedatablock( &irstou, "displacement", (void*)(array1), &nitems, "double", phasta_iotype );

    closefile( &irstou, "append" );
    
}

void
Write_GradPhi(  int* pid, 
                int* stepno, 
                int* nshg, 
                int* numVars,
		double* x,
                double* y, 
                double* gradphi,
		double* mag ) {

    char fname[255];
    char rfile[60];
    FILE* file=NULL ;
    int j;
    int irstou;
    int magic_number = 362436;
    int* mptr = &magic_number;
    time_t timenow = time ( &timenow);
    double version=0.0;
    int isize, nitems;
    int iarray[10];

//    sprintf(rfile,"gradphi_asc.%d.%d",*stepno,*pid+1);
//    file = fopen(rfile, "a" );
//    fprintf(file,"node x y z phi phi,x phi,y phi,z mag\n");
//
//    for(j=0; j<*nshg; j++){
//       fprintf(file,"%d %f %f %f %f %f %f %f %f\n",j,x[j],x[j+*nshg*1],x[j+*nshg*2],y[j+*nshg*5],gradphi[j],gradphi[j+*nshg*1],gradphi[j+*nshg*2],mag[j]);
//    }
//    fprintf(file,"\n"); 
//
//    fclose(file);
//
//
// Binary version
//

    sprintf(rfile,"gradphi.%d.%d",*stepno,*pid+1);
    openfile(rfile,"write", &irstou);

    /* writing the top ascii header for the gradphi file */

    writestring( &irstou,"# PHASTA GradPhi File Version 1.0\n");
    writestring( &irstou,
                  "# format \"keyphrase : sizeofnextblock usual headers\"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# Output generated by phasta version (NOT YET CURRENT): %lf \n", version);
    writestring( &irstou, fname );

    bzero( (void*)fname, 255 );
    gethostname(fname,255);
    writestring( &irstou,"# This result was produced on: ");
    writestring( &irstou, fname );
    writestring( &irstou,"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# %s\n", ctime( &timenow ));
    writestring( &irstou, fname );
        
    isize = 1;
    nitems = 1;
    iarray[ 0 ] = 1;
    writeheader( &irstou, "byteorder magic number ", 
                  (void*)iarray, &nitems, &isize, "integer", phasta_iotype );
    
    nitems = 1;
    writedatablock( &irstou, "byteorder magic number ",
                     (void*)mptr, &nitems, "integer", phasta_iotype );
    
    
    bzero( (void*)fname, 255 );
    sprintf(fname,"number of modes : < 0 > %d\n", *nshg);
    writestring( &irstou, fname );
    
    bzero( (void*)fname, 255 );
    sprintf(fname,"number of variables : < 0 > %d\n", *numVars);
    writestring( &irstou, fname );
    
    isize = (*nshg)*(*numVars);
    nitems = 3;
    iarray[ 0 ] = (*nshg);
    iarray[ 1 ] = (*numVars);
    iarray[ 2 ] = (*stepno);
    writeheader( &irstou, "gradphi ", 
                  (void*)iarray, &nitems, &isize, "double", phasta_iotype );
    
        
    nitems = (*nshg)*(*numVars);
    writedatablock( &irstou, "gradphi ",
                     (void*)(gradphi), &nitems, "double", phasta_iotype );
        

    closefile( &irstou, "write" );
}

void
Write_PrimVert( int* pid,
                int* stepno,
                int* nshg,
                int* numVars,
                double* primvertval ) {

    char fname[255];
    char rfile[60];
    FILE* file=NULL ;
    int j;
    int irstou;
    int magic_number = 362436;
    int* mptr = &magic_number;
    time_t timenow = time ( &timenow);
    double version=0.0;
    int isize, nitems;
    int iarray[10];

// Binary version
//

    sprintf(rfile,"primvert.%d.%d",*stepno,*pid+1);
    openfile(rfile,"write", &irstou);

    /* writing the top ascii header for the gradphi file */

    writestring( &irstou,"# PHASTA Primary Vertex File Version 1.0\n");
    writestring( &irstou,
                  "# format \"keyphrase : sizeofnextblock usual headers\"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# Output generated by phasta version (NOT YET CURRENT): %lf \n", version);
    writestring( &irstou, fname );

    bzero( (void*)fname, 255 );
    gethostname(fname,255);
    writestring( &irstou,"# This result was produced on: ");
    writestring( &irstou, fname );
    writestring( &irstou,"\n");

    bzero( (void*)fname, 255 );
    sprintf(fname,"# %s\n", ctime( &timenow ));
    writestring( &irstou, fname );

    isize = 1;
    nitems = 1;
    iarray[ 0 ] = 1;
    writeheader( &irstou, "byteorder magic number ",
                  (void*)iarray, &nitems, &isize, "integer", phasta_iotype );

    nitems = 1;
    writedatablock( &irstou, "byteorder magic number ",
                     (void*)mptr, &nitems, "integer", phasta_iotype );


    bzero( (void*)fname, 255 );
    sprintf(fname,"number of modes : < 0 > %d\n", *nshg);
    writestring( &irstou, fname );

    bzero( (void*)fname, 255 );
    sprintf(fname,"number of variables : < 0 > %d\n", *numVars);
    writestring( &irstou, fname );

    isize = (*nshg)*(*numVars);
    nitems = 3;
    iarray[ 0 ] = (*nshg);
    iarray[ 1 ] = (*numVars);
    iarray[ 2 ] = (*stepno);
    writeheader( &irstou, "primvert",
                  (void*)iarray, &nitems, &isize, "double", phasta_iotype );


    nitems = (*nshg)*(*numVars);
    writedatablock( &irstou, "primvert",
                     (void*)(primvertval), &nitems, "double", phasta_iotype );


    closefile( &irstou, "write" );
}

void
Write_Field(  int *pid,
              char* filemode,
              char* fieldtag,
              int* tagsize,
              void* array,
              char* arraytype,
              int* nshg,
              int* numvars,
              int* stepno) {

    char rfile[32];
    // assuming restart.sn.(pid+1)
    if (workfc.numpe > fronts.idirtrigger) {
        if(outpar.iMeshingTool == 1) {
        sprintf(rfile,"%d/restart.%d.%d",((int)((*pid)/fronts.idirstep)),*stepno,*pid+1);  //For Chef runs
        }
        else if(outpar.iMeshingTool == 0) {
        sprintf(rfile,"%d-set/restart.%d.%d",((int)((*pid)/fronts.idirstep))*fronts.idirstep,*stepno,*pid+1);   // Igor, August 2012
        }

        }
     else
    sprintf(rfile,"restart.%d.%d",*stepno,*pid+1);

    char *fieldlabel = (char *)malloc((*tagsize+1)*sizeof(char));
    strncpy(fieldlabel, fieldtag, *tagsize);
    fieldlabel[*tagsize] = '\0';

    int irstou;
    int magic_number = 362436;
    int* mptr = &magic_number;
    time_t timenow = time ( &timenow);
    double version=0.0;
    int isize, nitems;
    int iarray[10];

    char fmode[10];
    if(!strncmp(filemode,"w",1))
      strcpy(fmode,"write");
    else // default is append
      strcpy(fmode,"append");

    char datatype[10];
    if(!strncmp(arraytype,"i",1))
      strcpy(datatype,"int");
    else // default is double
      strcpy(datatype,"double");

    openfile(rfile, fmode, &irstou);

    nitems = 3; // assuming field will write 3 items in iarray
    iarray[ 0 ] = (*nshg);
    iarray[ 1 ] = (*numvars);
    iarray[ 2 ] = (*stepno);

    isize = (*nshg)*(*numvars);
    writeheader( &irstou, fieldlabel, (void*)iarray, &nitems, &isize, datatype, phasta_iotype );

    nitems = (*nshg)*(*numvars);
    writedatablock( &irstou, fieldlabel, array, &nitems, datatype, phasta_iotype );

    closefile( &irstou, fmode);

    free(fieldlabel);
}

