#ifndef __NEW_INTERFACE_H__
#define __NEW_INTERFACE_H__

#include <FCMangle.h>

//MR CHANGE
#define igetMinMaxAvg FortranCInterface_GLOBAL_(igetminmaxavg,IGETMINMAXAVG)
#define rgetMinMaxAvg FortranCInterface_GLOBAL_(rgetminmaxavg,RGETMINMAXAVG)
#define print_mesh_stats FortranCInterface_GLOBAL_(print_mesh_stats,PRINT_MESH_STATS)
#define print_mpi_stats FortranCInterface_GLOBAL_(print_mpi_stats,PRINT_MPI_STATS)
#define print_system_stats FortranCInterface_GLOBAL_(print_system_stats,PRINT_SYSTEM_STATS)
//MR CHANGE END
#define Write_Restart FortranCInterface_GLOBAL_(write_restart,WRITE_RESTART)
#define Write_Error   FortranCInterface_GLOBAL_(write_error,WRITE_ERROR)
#define Write_Displ   FortranCInterface_GLOBAL_(write_displ,WRITE_DISPL)
#define Write_GradPhi   FortranCInterface_GLOBAL_(write_gradphi,WRITE_GRADPHI)
#define Write_PrimVert   FortranCInterface_GLOBAL_(write_primvert,WRITE_PRIMVERT)
#define Write_Field   FortranCInterface_GLOBAL_(write_field,WRITE_FIELD)

extern char phasta_iotype[80];

void igetMinMaxAvg(int *ivalue, double *stats, int *statRanks);
void rgetMinMaxAvg(double *value, double *stats, int *statRanks);
void print_mesh_stats(void);
void print_mpi_stats(void);
void print_system_stats(double *tcorecp);

void
Write_Restart(  int* pid,
                int* stepno,
                int* nshg,
                int* numVars,
		double* soltime,
                double* array1,
                double* array2 );

void
Write_Error(  int* pid,
              int* stepno,
              int* nshg,
              int* numVars,
              double* array1 );

void
Write_Displ(  int* pid,
              int* stepno,
              int* nshg,
              int* numVars,
              double* array1 );

void
Write_GradPhi(  int* pid, 
                int* stepno, 
                int* nshg, 
                int* numVars,
		double* x,
                double* y, 
                double* gradphi,
		double* mag );

void
Write_PrimVert( int* pid,
                int* stepno,
                int* nshg,
                int* numVars,
                double* primvertval );

void
Write_Field(  int *pid,
              char* filemode,
              char* fieldtag,
              int* tagsize,
              void* array,
              char* arraytype,
              int* nshg,
              int* numvars,
              int* stepno );

#endif //header guard
