extern   int phasta ( int argc,  char* argv[] );
int 
main( int argc,   
      char *argv[] ) {

 /*    DO NOT ADD ANYTHING TO THIS ROUTINE. IT IS A STUB MAIN.   */
/*     THE TRUE MAIN IS IN ../common/phasta.cc */

  phasta (argc,argv);  
  
  return 0;
}
