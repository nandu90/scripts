#ifndef __PHIOTMRC_H__
#define __PHIOTMRC_H__

double phiotmrc (void);

#endif // __PHIOTMRC_H__

