#!/bin/sh

mpirun -np 16 ./regress_test 50400 16 4
