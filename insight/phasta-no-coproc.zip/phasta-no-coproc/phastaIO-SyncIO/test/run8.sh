#!/bin/sh

mpirun -np 8 ./regress_test 0 8 4
