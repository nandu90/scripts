gmake clean
gmake setup
gmake  
